% Project B - 3
% Satellite control in orbit around the Earth
%%%%%
% T group
%   Daniele Nanni Cirulli
%   Matteo Longhi
%   Luca Torzi


clear all; close all; clc
syms x1 x2 x3 u; 

%% definition of the parameter of the system
kg=6.67*10^(-11);   % universal gravitation constant
M=5.98*10^24;       % mass of the Earth
m=250;              % mass of the satellite
b1=0.25;            % coefficients of friction
b2=2.5;
k=3.5;              
pe=3*(10^8);        % equilibrium distance of the satellite


%% specifications to be respected

% the steady state error must be zero
% phase margin >= 55 deg

% maximum overshoot and settling time at 1%
S_100_spec = 0.01;
T_a1_spec = 0.05;

% reduction of the outgoing noise
A_d = 35;
omega_d_MAX = 0.5;

% reduction of the measurement error
A_n = 70;
omega_n_min = 2.5e4;
omega_n_MAX = 1e5;


%% declaration of the system f(x,u)

f1=x2;
f2=(-b1*x2)/(m) + (k-1)*(kg*M/(x1^2) - x1*(x3^2) );
f3=-2*(x3*x2)/(x1) -(b2*x3)/m +u/(m*x1); 


%% definition of the equilibrium point

x1e=pe;
x2e=0;
x3e=(M^(1/2)*kg^(1/2))/pe^(3/2);
ue=kg^(1/2)*M^(1/2)/(pe^(1/2))*b2;


%% calculation of the matrices of the linearized system

A=jacobian([f1,f2,f3],[x1,x2,x3]);
B=jacobian([f1,f2,f3],u);
C=[0,0,1];
D=0;
x1=x1e;
x2=x2e;
x3=x3e;
u=ue;
A=eval(A);
B=eval(B);
eig(A);

%% calculation of the transfer function
s=tf('s');
G=ss(A,B,C,D);
fprintf("Transfer Function:");
zpk(G);
zero(G);
pole(G);


%% calculation of the restriction on the S% and phase margin
xi = 0.83;
S_100 = 100*exp(-pi*xi/sqrt(1-xi^2));
Mf_spec = xi*100; 

omega_c_min=300/(Mf_spec*T_a1_spec);
omega_c_MAX = omega_n_min;

phi_spec = Mf_spec - 180;


%% bound for the plot
omega_plot_min = 1e-10;
omega_plot_max = 1e6;

% restriction on d
omega_d_min = 1e-10;
Bnd_d_x = [omega_d_min; omega_d_MAX; omega_d_MAX; omega_d_min];
Bnd_d_y = [A_d; A_d; -500; -500];

% restriction on n
Bnd_n_x = [omega_n_min; omega_n_MAX; omega_n_MAX; omega_n_min];
Bnd_n_y = [-A_n; -A_n; 400; 400];

% restriction on settling time
omega_Ta_min = 1e-10; 
omega_Ta_MAX =  omega_c_min;
Bnd_Ta_x = [omega_Ta_min; omega_Ta_MAX; omega_Ta_MAX; omega_Ta_min];
Bnd_Ta_y = [0; 0; -150; -150];

% restriction on the phase
phi_low = -270; 
Bnd_Mf_x = [omega_c_min; omega_c_MAX; omega_c_MAX; omega_c_min];
Bnd_Mf_y = [phi_spec; phi_spec; phi_low; phi_low];



%% plot of the transfer function

figure(1);
hold on;

% magnitude restriction
patch(Bnd_d_x, Bnd_d_y,'r','FaceAlpha',0.2,'EdgeAlpha',0);
patch(Bnd_n_x, Bnd_n_y,'g','FaceAlpha',0.2,'EdgeAlpha',0);
patch(Bnd_Ta_x, Bnd_Ta_y,'b','FaceAlpha',0.2,'EdgeAlpha',0);

% Plot Bode of the transfer function with margins of stability
margin(G,{omega_plot_min,omega_plot_max});
grid on; zoom on;






%% static controller design
% to have a zero staedy state error we insert a pole in the origin
% (since the initial function does not have one)

mu_s=1e12;
R_s=mu_s/(s);

% new transfer function in series with the static controller
G_e=R_s*tf(G);


%% Bode plot of the static controller
figure(2);
hold on;

% magnitude restriction
patch(Bnd_d_x, Bnd_d_y,'r','FaceAlpha',0.2,'EdgeAlpha',0);
patch(Bnd_n_x, Bnd_n_y,'g','FaceAlpha',0.2,'EdgeAlpha',0);
patch(Bnd_Ta_x, Bnd_Ta_y,'b','FaceAlpha',0.2,'EdgeAlpha',0);

% Bode Plot of the static controller with margins of stability
margin(G_e,{omega_plot_min,omega_plot_max});
grid on; zoom on;

% phase restriction
patch(Bnd_Mf_x, Bnd_Mf_y,'g','FaceAlpha',0.2,'EdgeAlpha',0);





%% dinamic controller design
    
Mf_star = Mf_spec; 
omega_c_star = 1000;
[mag_omega_c_star, arg_omega_c_star, omega_c_star] = bode(G_e, omega_c_star);
    
mag_omega_c_star_dB = 20*log10(mag_omega_c_star);
    
M_star = 10^(-mag_omega_c_star_dB/20);
phi_star = Mf_star - 180 - arg_omega_c_star;
    
   
tau_b = (M_star - cos(phi_star*pi/180))/omega_c_star/sin(phi_star*pi/180);
alpha_tau_b = (cos(phi_star*pi/180) - inv(M_star))/omega_c_star/sin(phi_star*pi/180);
alpha_b = alpha_tau_b / tau_b;
    
check_flag = cos(phi_star*pi/180) - inv(M_star);
if check_flag < 0
    disp('Error: alpha_b < 0');
    return;
end

R_d_r=(1+ 1e1*s)/((1+ 10e1*s)*(1+ 0.0002*s));
R_d_a = (1 + tau_b*s)/((1 + alpha_b * tau_b*s));
LL=G_e*R_d_a*R_d_r;
R=mu_s*R_d_a*R_d_r;



%% Bode plot of the dinamic controller
figure(3);
hold on;

% magnitude restriction
patch(Bnd_d_x, Bnd_d_y,'r','FaceAlpha',0.2,'EdgeAlpha',0);
patch(Bnd_n_x, Bnd_n_y,'g','FaceAlpha',0.2,'EdgeAlpha',0);
patch(Bnd_Ta_x, Bnd_Ta_y,'b','FaceAlpha',0.2,'EdgeAlpha',0);

% Bode Plot
margin(LL,{omega_plot_min,omega_plot_max});
grid on; zoom on;

% phase restriction
patch(Bnd_Mf_x, Bnd_Mf_y,'g','FaceAlpha',0.2,'EdgeAlpha',0);
hold on;





%% Step input test
stepAmplitude=3e-7;

FF=LL/(1+LL);
figure();
[y_step, t_step]=step(-1*stepAmplitude*FF, 2);
plot(t_step, y_step);


%% Output noise test

% Sensitivity function
SS = 1/(1+LL);
figure();

% output noise simulation
DD=2e-8;
omega_d = 0.125;
tt = (0:1e-2:1e3)';
dd = DD*(cos(omega_d*tt)+cos(2*omega_d*tt)+cos(3*omega_d*tt)+cos(4*omega_d*tt));
y_d = lsim(SS,dd,tt);

%plot of the output 
hold on, grid on, zoom on
plot(tt,dd,'m')
plot(tt,y_d,'b')
grid on
legend('dd','y_d')




%% Measurement error test

figure();

% Measurement error simulation
NN=3e-8;
omega_n = 2.5e4;
tt = (0:1e-5:1)';
nn = NN*(cos(omega_n*tt)+cos(2*omega_n*tt)+cos(3*omega_n*tt)+cos(4*omega_n*tt));
y_n = lsim(-FF,nn,tt);

%plot of the output 
hold on, grid on, zoom on
plot(tt,nn,'m')
plot(tt,y_n,'b')
grid on
legend('nn','y_n')



